# Configuración de Administrador - Panel Carol

## Paso 1: Crear Cuenta de Administrador

1. Ve a la landing page de la aplicación
2. En la parte inferior, haz clic en el enlace pequeño "Admin Access"
3. En la página de login, haz clic en "¿No tienes cuenta? Regístrate"
4. Completa el formulario con:
   - Nombre completo
   - Email de Carol
   - Contraseña segura
5. Haz clic en "Crear Cuenta"

## Paso 2: Dar Permisos de Admin

Después de crear la cuenta, necesitas darle permisos de administrador. Esto solo se hace una vez.

### Opción A: Desde Lovable (Recomendado)

1. En Lovable, haz clic en el botón "Ver Base de Datos" en el chat
2. Ve a la tabla `user_roles`
3. Haz clic en "Insert row"
4. Completa:
   - `user_id`: (Copia el ID del usuario desde la tabla `profiles`)
   - `role`: Selecciona `admin`
5. Haz clic en "Save"

### Opción B: Con SQL

1. En el backend de Lovable Cloud, ve a SQL Editor
2. Ejecuta esta consulta (reemplaza el email):

```sql
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role
FROM auth.users
WHERE email = 'carol@email.com';
```

## Paso 3: Acceder al Panel

1. Ve a `/auth` en la aplicación
2. Inicia sesión con las credenciales creadas
3. Serás redirigido automáticamente a `/admin`

## Características del Panel de Admin

- ✅ Ver todas las reservas
- ✅ Datos completos de clientes (nombre, email, teléfono)
- ✅ Estado de pagos
- ✅ Filtrar y ordenar reservas
- ✅ Actualizar en tiempo real
- ✅ Exportar datos (desde la tabla en el backend)

## Seguridad

- Solo usuarios con rol `admin` pueden acceder al panel
- Las contraseñas están encriptadas
- Los emails se auto-confirman (no necesitas verificar email)
- La sesión permanece activa entre visitas

## Soporte

Para cualquier problema, contacta al desarrollador o consulta la base de datos directamente desde Lovable.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendMassWhatsAppRequest {
  message: string;
  groupCallLink?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Verify admin authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    // Check if user is admin
    const { data: roleData, error: roleError } = await supabaseClient
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (roleError || roleData?.role !== 'admin') {
      throw new Error('Unauthorized - Admin access required');
    }

    const { message, groupCallLink }: SendMassWhatsAppRequest = await req.json();

    if (!message) {
      throw new Error('Message is required');
    }

    // Get all bookings with phone numbers
    const { data: bookings, error: bookingsError } = await supabaseClient
      .from('bookings')
      .select('client_name, client_phone, client_email')
      .not('client_phone', 'is', null);

    if (bookingsError) {
      console.error('Error fetching bookings:', bookingsError);
      throw new Error('Failed to fetch client list');
    }

    if (!bookings || bookings.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No clients with phone numbers found',
          sentCount: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Prepare Twilio credentials
    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const twilioPhone = Deno.env.get('TWILIO_PHONE_NUMBER');

    if (!accountSid || !authToken || !twilioPhone) {
      throw new Error('Twilio credentials not configured');
    }

    // Send WhatsApp messages
    const results = [];
    for (const booking of bookings) {
      try {
        let fullMessage = `Hello ${booking.client_name}! 👋\n\n${message}`;
        
        if (groupCallLink) {
          fullMessage += `\n\n🔗 Group Call Link: ${groupCallLink}`;
        }

        fullMessage += `\n\n- Caroline Stanbury`;

        const response = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
          {
            method: 'POST',
            headers: {
              'Authorization': 'Basic ' + btoa(`${accountSid}:${authToken}`),
              'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
              From: `whatsapp:${twilioPhone}`,
              To: `whatsapp:${booking.client_phone}`,
              Body: fullMessage,
            }),
          }
        );

        if (response.ok) {
          results.push({ phone: booking.client_phone, success: true });
          console.log(`Message sent to ${booking.client_name} (${booking.client_phone})`);
        } else {
          const errorData = await response.text();
          console.error(`Failed to send to ${booking.client_phone}:`, errorData);
          results.push({ phone: booking.client_phone, success: false, error: errorData });
        }
      } catch (error) {
        console.error(`Error sending to ${booking.client_phone}:`, error);
        results.push({ phone: booking.client_phone, success: false, error: String(error) });
      }
    }

    const successCount = results.filter(r => r.success).length;

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Messages sent successfully to ${successCount} out of ${bookings.length} clients`,
        sentCount: successCount,
        totalClients: bookings.length,
        results 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in send-mass-whatsapp:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : String(error) }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_PHONE_NUMBER = Deno.env.get('TWILIO_PHONE_NUMBER');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface BookingConfirmation {
  booking_id: string;
  client_name: string;
  client_email: string;
  client_phone: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { client_name, client_email, client_phone }: BookingConfirmation = await req.json();

    console.log('Sending confirmation to:', { client_name, client_email, client_phone });

    // Send WhatsApp message via Twilio
    const whatsappMessage = `Hi ${client_name}! 🌟

Thank you for registering with Caroline Stanbury! We've received your information and are excited to help you on your transformation journey.

Your registration is confirmed. You'll receive further details about your session shortly.

StanburyTalks Team`;

    // Format phone number for WhatsApp (must include country code)
    const formattedPhone = client_phone.startsWith('+') ? client_phone : `+${client_phone}`;
    
    const twilioResponse = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`)
        },
        body: new URLSearchParams({
          From: `whatsapp:${TWILIO_PHONE_NUMBER}`,
          To: `whatsapp:${formattedPhone}`,
          Body: whatsappMessage
        })
      }
    );

    if (!twilioResponse.ok) {
      const errorText = await twilioResponse.text();
      console.error('Twilio error:', errorText);
      throw new Error(`Failed to send WhatsApp message: ${errorText}`);
    }

    const twilioData = await twilioResponse.json();
    console.log('WhatsApp message sent successfully:', twilioData.sid);

    // TODO: Add email sending here using Resend when ready
    // For now, we'll just log that email would be sent
    console.log('Email confirmation would be sent to:', client_email);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Confirmation sent via WhatsApp',
        twilio_sid: twilioData.sid
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error in send-booking-confirmation:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        details: 'Failed to send confirmation. Please check logs.'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

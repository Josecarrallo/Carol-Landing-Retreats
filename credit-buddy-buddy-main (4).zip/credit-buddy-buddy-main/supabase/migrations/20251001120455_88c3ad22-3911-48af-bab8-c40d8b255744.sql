-- Remove the public SELECT policy that allows anyone to view all bookings
DROP POLICY IF EXISTS "Users can view their own bookings" ON public.bookings;

-- Create a new restrictive SELECT policy that denies all public access
-- This ensures booking data cannot be queried directly from the client
CREATE POLICY "Bookings are private" 
ON public.bookings 
FOR SELECT 
USING (false);

-- Keep the INSERT policy for creating new bookings
-- This allows the registration flow to work
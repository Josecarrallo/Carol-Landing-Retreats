# 🔐 Configuración Admin para Carol

## 1️⃣ Carol debe registrarse

1. Ve a: **https://tu-app.lovable.app/auth**
2. Haz clic en **"¿No tienes cuenta? Regístrate"**
3. Completa:
   - Email: carol@email.com
   - Contraseña: (una que recuerde)
   - Nombre completo: Caroline Stanbury
4. Clic en **"Crear Cuenta"**

---

## 2️⃣ Tú le das permisos de Admin

**Después de que Carol se registre**, ejecuta este SQL en el backend:

```sql
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role
FROM auth.users
WHERE email = 'carol@email.com';
```

### Cómo ejecutar el SQL:

1. En Lovable, haz clic en el botón **"View Backend"** aquí abajo:

<lov-actions>
  <lov-open-backend>Abrir Backend</lov-open-backend>
</lov-actions>

2. Ve a **SQL Editor** (menú izquierdo)
3. Pega el SQL de arriba (cambia el email si Carol usa otro)
4. Haz clic en **"Run"**

---

## 3️⃣ Carol ya puede acceder

Carol entra a: **https://tu-app.lovable.app/auth**

Verá:
- ✅ Todas las reservas con datos completos
- ✅ Enviar mensajes masivos por WhatsApp
- ✅ Crear y enviar links de llamadas grupales (Google Meet/Zoom)

---

## ⚠️ IMPORTANTE

- Solo el admin (tú) puede dar permisos de admin
- Carol **NO PUEDE** darse permisos a sí misma
- El SQL solo funciona **DESPUÉS** de que Carol se registre

import carolineImage1 from "@/assets/caroline-new.jpg";
import carolineImage2 from "@/assets/caroline-2.jpg";

export const About = () => {
  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-10 text-foreground">
          Meet Caroline Stanbury
        </h2>
        
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div className="space-y-6 text-muted-foreground text-center md:text-left">
            <p className="text-lg md:text-xl leading-relaxed">
              Reality TV star, entrepreneur, wellness advocate, and passionate advocate for living 
              authentically. Caroline has spent years navigating the pressures of public life, 
              learning to break free from societal labels and embrace her true self.
            </p>
            <p className="text-lg md:text-xl leading-relaxed">
              Through her personal journey, Caroline discovered the transformative power of wellness, 
              mindfulness, and self-love. Now, she's dedicated to helping others shed the expectations 
              and judgments that hold them back.
            </p>
            <blockquote className="border-l-4 border-primary pl-6 italic text-xl md:text-2xl">
              "I've lived under labels my whole life—and I'm done with them. This retreat is about 
              helping you find the courage to do the same."
              <footer className="mt-3 text-base not-italic">— Caroline Stanbury</footer>
            </blockquote>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <img 
              src={carolineImage1} 
              alt="Caroline Stanbury portrait" 
              className="w-full h-full object-cover rounded-lg"
            />
            <img 
              src={carolineImage2} 
              alt="Caroline Stanbury wellness" 
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

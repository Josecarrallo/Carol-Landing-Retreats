import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import carolineHero from "@/assets/caroline-1.jpg";
import { useNavigate } from "react-router-dom";

export const Hero = () => {
  const navigate = useNavigate();
  
  const goToRegistration = () => {
    navigate('/registration');
  };

  return (
    <section 
      className="relative min-h-screen flex flex-col"
      style={{
        backgroundImage: `url(${carolineHero})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center 30%',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-transparent to-black/90" />
      
      {/* Top content - Title and icon */}
      <div className="relative z-10 text-center -mt-6 md:-mt-5">
        <Sparkles className="w-6 h-6 md:w-7 md:h-7 mx-auto mb-2 text-primary drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]" />
        <h1 className="text-xl md:text-3xl lg:text-4xl font-bold text-white leading-tight px-4 max-w-4xl mx-auto" style={{ textShadow: '0 4px 12px rgba(0,0,0,0.9), 0 2px 4px rgba(0,0,0,0.8)' }}>
          Conversations with Caroline Stanbury - Unfiltered, unapologetic, and fully in her power.
        </h1>
      </div>
      
      {/* Spacer to push content to bottom */}
      <div className="flex-grow"></div>
      
      {/* Bottom content - Description and CTA */}
      <div className="relative z-10 text-center pb-12 md:pb-16 max-w-3xl mx-auto px-4">
        <p className="text-lg md:text-xl text-white mb-2 font-semibold leading-relaxed" style={{ textShadow: '0 3px 8px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.8)' }}>
          Your Moment of Transformation Awaits
        </p>
        <p className="text-sm md:text-base text-white mb-3 md:mb-4 leading-relaxed" style={{ textShadow: '0 2px 6px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.8)' }}>
          After multiple sold-out retreats worldwide, Caroline is opening exclusive 1:1 audio and video sessions. 
          Choose from 10 to 35-minute transformative conversations designed to unlock your potential, 
          reset your mindset, and guide you to breakthrough clarity.
        </p>
        <p className="text-sm md:text-base text-white mb-8 font-medium leading-relaxed" style={{ textShadow: '0 2px 6px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.8)' }}>
          Whether you're facing life challenges, seeking relationship guidance, or ready for personal transformation—
          this is your opportunity to connect directly with Caroline.
        </p>
        <Button 
          size="lg" 
          onClick={goToRegistration}
          className="bg-primary hover:bg-primary/90 text-primary-foreground px-12 py-7 text-lg md:text-xl font-bold rounded-full shadow-2xl animate-pulse hover:animate-none"
        >
          🌟 Secure Your Exclusive Session Now
        </Button>
      </div>
    </section>
  );
};

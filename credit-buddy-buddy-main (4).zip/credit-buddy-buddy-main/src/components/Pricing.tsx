import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, Video } from "lucide-react";

const pricingOptions = [
  {
    type: "Audio Call",
    duration: "10 minutes",
    price: "$275",
    description: "Clarity session to reset your mindset and gain instant guidance",
    icon: Phone,
    emoji: "💭",
    popular: false
  },
  {
    type: "Video Call",
    duration: "15 minutes",
    price: "$350",
    description: "Deep dive to explore your challenges face-to-face",
    icon: Video,
    emoji: "✨",
    popular: true
  },
  {
    type: "Audio Call",
    duration: "20 minutes",
    price: "$400",
    description: "Extended coaching for comprehensive guidance",
    icon: Phone,
    emoji: "🎯",
    popular: false
  },
  {
    type: "Video Call",
    duration: "25 minutes",
    price: "$500",
    description: "Intensive strategy session for breakthrough solutions",
    icon: Video,
    emoji: "💎",
    popular: true
  },
  {
    type: "Video Call",
    duration: "35 minutes",
    price: "$750",
    description: "Premium transformation for complete life makeover",
    icon: Video,
    emoji: "👑",
    popular: false
  }
];

export const Pricing = () => {
  return (
    <section id="pricing" className="py-20 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-foreground">
          Session Options & Pricing
        </h2>
        <p className="text-center text-muted-foreground mb-12">
          Choose the experience that suits you
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {pricingOptions.map((option, index) => {
            const Icon = option.icon;
            return (
              <Card key={index} className="relative">
                {option.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                    POPULAR
                  </Badge>
                )}
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <Icon className="w-8 h-8 text-primary" />
                    <span className="text-3xl">{option.emoji}</span>
                  </div>
                  <CardTitle className="text-foreground">{option.type}</CardTitle>
                  <CardDescription>{option.duration}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-2 text-foreground">{option.price}</div>
                  <p className="text-sm text-muted-foreground">{option.description}</p>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" onClick={() => window.location.href = '/registration'}>
                    Book Now
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
        
        <Card className="bg-muted/30">
          <CardHeader>
            <CardTitle className="text-foreground">Important Notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="flex items-start gap-2 text-foreground">
              <span className="text-primary">•</span>
              <span>Spaces are extremely limited and in high demand.</span>
            </p>
            <p className="flex items-start gap-2 text-foreground">
              <span className="text-primary">•</span>
              <span>Calls are non-refundable once booked.</span>
            </p>
            <p className="flex items-start gap-2 text-foreground">
              <span className="text-primary">•</span>
              <span>Rescheduling is possible with 48 hours' notice.</span>
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

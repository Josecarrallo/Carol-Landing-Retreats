import { Check } from "lucide-react";
import carolineGallery from "@/assets/caroline-gallery.png";

const benefits = [
  "Get Caroline's unfiltered advice",
  "Learn from her global experience in business & lifestyle",
  "Share your story in a private, safe space",
  "Walk away inspired with actionable insights",
  "Talk openly about relationships or struggles with divorce",
  "Gain clarity on business challenges and opportunities",
  "Break free from feeling stuck in life",
  "Explore pathways to financial freedom"
];

export const WhyBook = () => {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-6 text-foreground">
          Why Book a Call?
        </h2>
        
        <p className="text-lg text-muted-foreground text-center mb-6 max-w-4xl mx-auto">
          Caroline Stanbury – luxury entrepreneur, TV personality (The Real Housewives of Dubai, 
          Ladies of London, The Traitors USA), and global brand ambassador – has inspired millions 
          through her platforms, retreats, and podcast.
        </p>
        
        <div className="mb-4 max-w-4xl mx-auto">
          <img 
            src={carolineGallery} 
            alt="Caroline Stanbury media gallery" 
            className="w-full h-auto rounded-lg shadow-md"
          />
        </div>
        
        <p className="text-base text-muted-foreground text-center mb-6 max-w-4xl mx-auto">
          Now, in this limited-time offer outside her retreats, you can book a direct personal 
          session with Caroline. Whether you want advice on business, life, relationships, or 
          simply a candid conversation, this is your chance to connect.
        </p>
        
        <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center flex-shrink-0 mt-1">
                <Check className="w-5 h-5 text-white" strokeWidth={3} />
              </div>
              <span className="text-muted-foreground">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

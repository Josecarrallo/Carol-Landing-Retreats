import { Button } from "@/components/ui/button";
import { Calendar, CheckCircle, Video, Podcast, Instagram, Youtube } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { FaTiktok } from "react-icons/fa";
import { ExternalLink } from "lucide-react";

const steps = [
  {
    number: "1",
    title: "Select & Book",
    description: "Select your call type & book securely via Stripe.",
    icon: Calendar
  },
  {
    number: "2",
    title: "Confirmation",
    description: "Receive a confirmation email with your scheduled time.",
    icon: CheckCircle
  },
  {
    number: "3",
    title: "Connect",
    description: "Connect directly with Caroline via private link.",
    icon: Video
  }
];

export const HowItWorks = () => {
  const navigate = useNavigate();
  
  const goToRegistration = () => {
    navigate('/registration');
  };

  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-foreground">
          How It Works
        </h2>
        <p className="text-center text-muted-foreground mb-12">
          Three simple steps to your personal session with Caroline
        </p>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.number} className="text-center">
                <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {step.number}
                </div>
                <Icon className="w-8 h-8 mx-auto mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-2 text-foreground">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            );
          })}
        </div>
        
        <div className="flex flex-col lg:flex-row items-center lg:items-start justify-center gap-8 w-full max-w-6xl mx-auto">
          {/* Contenido Principal - Centro */}
          <div className="flex-1 flex flex-col items-center justify-center gap-6 max-w-2xl">
            <p className="text-xl md:text-2xl text-foreground text-center font-semibold">
              Don't miss this rare opportunity to connect 1:1 with Caroline.
            </p>
            
            <Button 
              size="lg" 
              onClick={goToRegistration}
              className="px-16 py-8 text-2xl font-bold shadow-2xl hover:scale-105 transition-transform"
            >
              👉 Reserve Your Call Now
            </Button>
            
            {/* Iconos de Redes Sociales */}
            <div className="flex items-center gap-6 mt-4">
              <a 
                href="https://podcasts.apple.com/us/podcast/caroline-stanbury" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-purple-600 hover:text-purple-700 transition-colors"
                aria-label="Podcast"
              >
                <Podcast className="w-6 h-6" />
              </a>
              <a 
                href="https://www.instagram.com/carolinestanbury" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-pink-600 hover:text-pink-700 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-6 h-6" />
              </a>
              <a 
                href="https://www.tiktok.com/@carolinestanbury" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-black hover:text-gray-800 transition-colors"
                aria-label="TikTok"
              >
                <FaTiktok className="w-6 h-6" />
              </a>
              <a 
                href="https://www.youtube.com/@carolinestanbury" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-600 hover:text-red-700 transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-6 h-6" />
              </a>
              <a 
                href="https://BustTheLabel.com" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-orange-600 hover:text-orange-700 transition-colors flex items-center gap-1"
                aria-label="BustTheLabel.com"
              >
                <span className="text-sm font-medium">BustTheLabel.com</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
          
          {/* Caja Pequeña Join Retreat - Derecha */}
          <div className="w-52 bg-gradient-to-br from-orange-600 via-orange-500 to-orange-400 p-5 rounded-xl shadow-xl transform hover:scale-110 hover:rotate-1 transition-all duration-300 lg:ml-8">
            <div className="text-white text-center space-y-2">
              <div className="text-3xl">✨</div>
              <h3 className="text-base font-bold">Join Next Retreat?</h3>
              <Button 
                size="sm" 
                className="w-full bg-white text-orange-600 hover:bg-orange-50 font-bold py-2 text-xs shadow-lg"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
        
        <div className="mt-8 flex flex-col items-center">
          <a 
            href="/auth" 
            className="text-xs text-muted-foreground hover:text-primary transition-colors"
          >
            Admin Access
          </a>
        </div>
      </div>
    </section>
  );
};

import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const timeSlots = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
  "15:00", "15:30", "16:00", "16:30", "17:00", "17:30"
];

export default function Calendar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { bookingId, packageInfo } = location.state || {};
  
  const [date, setDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!packageInfo) {
      toast.error("Please select a package first");
      navigate('/packages');
    }
    // Allow access without bookingId for memberships
    if (!packageInfo?.isMembership && !bookingId) {
      toast.error("Please complete registration first");
      navigate('/registration');
    }
  }, [bookingId, packageInfo, navigate]);

  const handleContinueToPayment = async () => {
    if (!date || !selectedTime) {
      toast.error("Please select both date and time");
      return;
    }

    setLoading(true);
    try {
      // Combine date and time
      const [hours, minutes] = selectedTime.split(':');
      const selectedDateTime = new Date(date);
      selectedDateTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);

      // If it's a membership (no bookingId), go straight to payment
      if (packageInfo?.isMembership) {
        navigate('/payment', { 
          state: { 
            packageInfo,
            selectedDate: selectedDateTime.toISOString(),
            isMembership: true
          } 
        });
        return;
      }

      // For regular packages, update existing booking
      const { error } = await supabase
        .from('bookings')
        .update({ 
          selected_date: selectedDateTime.toISOString(),
          session_type: packageInfo.type.toLowerCase().replace(' call', ''),
          duration: parseInt(packageInfo.duration),
          price: parseInt(packageInfo.price.replace('$', ''))
        })
        .eq('id', bookingId);

      if (error) throw error;

      // Navigate to payment
      navigate('/payment', { 
        state: { 
          bookingId, 
          packageInfo,
          selectedDate: selectedDateTime.toISOString()
        } 
      });
    } catch (error: any) {
      console.error('Error updating booking:', error);
      toast.error(error.message || "Failed to save date/time");
    } finally {
      setLoading(false);
    }
  };

  if (!packageInfo) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">
            Schedule Your Session
          </h1>
          <p className="text-muted-foreground">
            {packageInfo.type} - {packageInfo.duration} - {packageInfo.price}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Date Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-foreground">Select Date</CardTitle>
              <CardDescription>Choose your preferred session date</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    disabled={(date) => date < new Date()}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </CardContent>
          </Card>

          {/* Time Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-foreground">Select Time</CardTitle>
              <CardDescription>Choose your preferred session time (EST)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2 max-h-[300px] overflow-y-auto">
                {timeSlots.map((time) => (
                  <Button
                    key={time}
                    variant={selectedTime === time ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedTime(time)}
                    className="w-full"
                  >
                    <Clock className="mr-1 h-3 w-3" />
                    {time}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary and Continue */}
        {date && selectedTime && (
          <Card className="mt-6 bg-muted/30">
            <CardHeader>
              <CardTitle className="text-foreground">Session Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-foreground"><strong>Package:</strong> {packageInfo.type} - {packageInfo.duration}</p>
              <p className="text-foreground"><strong>Price:</strong> {packageInfo.price}</p>
              <p className="text-foreground"><strong>Date:</strong> {format(date, "PPPP")}</p>
              <p className="text-foreground"><strong>Time:</strong> {selectedTime} EST</p>
            </CardContent>
          </Card>
        )}

        <div className="flex gap-4 mt-8">
          <Button
            variant="outline"
            onClick={() => navigate('/packages', { state: { bookingId } })}
            className="flex-1"
          >
            Back to Packages
          </Button>
          <Button
            onClick={handleContinueToPayment}
            disabled={!date || !selectedTime || loading}
            className="flex-1"
          >
            {loading ? "Processing..." : "Continue to Payment"}
          </Button>
        </div>
      </div>
    </div>
  );
}

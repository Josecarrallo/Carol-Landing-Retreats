import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Sparkles, MessageCircle, Target, TrendingUp } from "lucide-react";

export default function CoachingMemberships() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 py-6 px-4">
      <div className="max-w-6xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Sparkles className="w-8 h-8 text-primary animate-pulse" />
            <h1 className="text-4xl md:text-6xl font-extrabold bg-gradient-to-r from-primary via-orange-500 to-primary bg-clip-text text-transparent animate-fade-in">
              Coaching Memberships
            </h1>
            <Sparkles className="w-8 h-8 text-primary animate-pulse" />
          </div>
          <p className="text-lg md:text-xl text-muted-foreground max-w-4xl mx-auto">
            Exclusive coaching for deeply committed clients - life-changing conversations designed for lasting transformation
          </p>
        </div>

        <Card className="mb-8 bg-gradient-to-br from-primary/20 to-primary/30 border-primary/50">
          <CardHeader className="p-6">
            <CardTitle className="text-2xl md:text-3xl text-center font-bold bg-gradient-to-r from-primary via-orange-500 to-primary bg-clip-text text-transparent">
              Member-Only Access
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 pt-0">
            <p className="text-center text-base md:text-lg text-muted-foreground mb-8">
              An invitation-only opportunity for private, strategic coaching. Expect:
            </p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start gap-4 bg-background/60 p-6 rounded-xl border border-primary/30">
                <div className="bg-primary rounded-full p-3 flex-shrink-0">
                  <Target className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-1">Full Deep Dive</h3>
                  <p className="text-sm text-muted-foreground">Into your goals</p>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-background/60 p-6 rounded-xl border border-primary/30">
                <div className="bg-primary rounded-full p-3 flex-shrink-0">
                  <TrendingUp className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-1">Identify Patterns</h3>
                  <p className="text-sm text-muted-foreground">Holding you back</p>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-background/60 p-6 rounded-xl border border-primary/30">
                <div className="bg-primary rounded-full p-3 flex-shrink-0">
                  <Sparkles className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-1">Step-by-Step Strategies</h3>
                  <p className="text-sm text-muted-foreground">Long-term results</p>
                </div>
              </div>

              <div className="flex items-start gap-4 bg-background/60 p-6 rounded-xl border border-primary/30">
                <div className="bg-primary rounded-full p-3 flex-shrink-0">
                  <MessageCircle className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-1">Raw Conversations</h3>
                  <p className="text-sm text-muted-foreground">Open discussion</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button 
            className="px-6"
            onClick={() => navigate('/vip-coaching')}
          >
            Continue to Memberships
          </Button>
        </div>
      </div>
    </div>
  );
}

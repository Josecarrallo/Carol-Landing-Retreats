import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, Video, ArrowLeft, CheckCircle2, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const packages = [
  {
    type: "audio",
    duration: 15,
    price: 270,
    priceId: "price_audio_15min",
    title: "15-Minute Audio Call",
    description: "A short, laser-focused session designed to remove blocks fast and give you actionable next steps.",
    icon: Phone,
    features: [
      "Quick clarity on a pressing issue",
      "Confidence boost or motivation check-in",
      "Direction on a single challenge",
      "Career move, relationship, or decision-making guidance"
    ]
  },
  {
    type: "audio",
    duration: 30,
    price: 500,
    priceId: "price_audio_30min",
    title: "30-Minute Audio Call",
    description: "A deeper dive with enough time to explore multiple areas. Caroline will push you, challenge your thinking, and hold you accountable.",
    icon: Phone,
    features: [
      "Review personal or professional challenges in detail",
      "Gain perspective on strategy and mindset",
      "Create short-term action plans",
      "Immediate implementation steps"
    ]
  },
  {
    type: "video",
    duration: 15,
    price: 300,
    priceId: "price_video_15min",
    title: "15-Minute Video Call",
    description: "A short, laser-focused face-to-face session designed to remove blocks fast and give you actionable next steps.",
    icon: Video,
    popular: true,
    features: [
      "Quick clarity on a pressing issue",
      "Face-to-face connection with Caroline",
      "Direction on a single challenge",
      "Confidence boost or motivation check-in"
    ]
  },
  {
    type: "video",
    duration: 30,
    price: 750,
    priceId: "price_video_30min",
    title: "30-Minute Video Call",
    description: "A deeper dive face-to-face with Caroline. She will push you, challenge your thinking, and hold you accountable while keeping it focused.",
    icon: Video,
    features: [
      "Review challenges in detail face-to-face",
      "Gain perspective on both strategy and mindset",
      "Create actionable short-term plans",
      "Direct connection with Caroline"
    ]
  }
];

export default function Packages() {
  const navigate = useNavigate();
  const location = useLocation();
  const bookingId = location.state?.bookingId;

  const handleSelectPackage = (pkg: typeof packages[0]) => {
    if (!bookingId) {
      toast.error("No booking found. Please register first.");
      navigate('/registration');
      return;
    }

    // Navigate to calendar with package info
    navigate('/calendar', { 
      state: { 
        bookingId, 
        packageInfo: {
          type: pkg.title,
          duration: `${pkg.duration} minutes`,
          price: `$${pkg.price}`,
          priceId: pkg.priceId
        }
      } 
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 py-4 px-4">
      <div className="max-w-7xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-2"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <div className="text-center mb-4">
          <h1 className="text-3xl md:text-5xl font-extrabold mb-3 bg-gradient-to-r from-primary via-orange-500 to-primary bg-clip-text text-transparent animate-fade-in">
            Choose Your Transformation Package
          </h1>
          <p className="text-base md:text-lg text-muted-foreground max-w-3xl mx-auto">
            These sessions are life-changing conversations designed for lasting transformation
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          {packages.map((pkg, index) => {
            const Icon = pkg.icon;
            return (
              <Card key={index} className="relative hover:shadow-lg transition-shadow flex flex-col">
                {pkg.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                    MOST POPULAR
                  </Badge>
                )}
                <CardHeader className="flex-none p-3">
                  <Icon className="w-6 h-6 mb-1 text-primary flex-shrink-0" />
                  <CardTitle className="text-lg mb-1 flex-shrink-0">{pkg.title}</CardTitle>
                  <div className="text-2xl font-bold text-primary">${pkg.price}</div>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col p-3 pt-0">
                  <ul className="space-y-1 flex-grow">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3 h-3 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-xs">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="mt-auto p-3 pt-0">
                  <Button 
                    className="w-full text-sm py-2" 
                    onClick={() => handleSelectPackage(pkg)}
                  >
                    Select Package
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>

        <Card className="bg-gradient-to-br from-primary/20 to-primary/10 border-primary/40">
          <CardHeader className="text-center p-4">
            <div className="flex items-center justify-center gap-3 mb-1">
              <Sparkles className="w-6 h-6 text-primary animate-pulse" />
              <CardTitle className="text-xl md:text-2xl font-bold bg-gradient-to-r from-primary via-orange-500 to-primary bg-clip-text text-transparent">
                Join the VIP Coaching Membership Program
              </CardTitle>
              <Sparkles className="w-6 h-6 text-primary animate-pulse" />
            </div>
          </CardHeader>
          <CardContent className="text-center p-4 pt-0">
            <Button 
              className="hover:scale-105 transition-transform"
              onClick={() => navigate('/coaching-memberships')}
            >
              Explore Memberships
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

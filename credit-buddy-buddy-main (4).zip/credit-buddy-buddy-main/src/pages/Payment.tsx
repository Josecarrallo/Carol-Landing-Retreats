import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export default function Payment() {
  const navigate = useNavigate();
  const location = useLocation();
  const { bookingId, packageInfo, selectedDate, isMembership } = location.state || {};
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!packageInfo || !selectedDate) {
      toast.error("Missing booking information");
      navigate('/packages');
    }
    // Allow memberships without bookingId
    if (!isMembership && !bookingId) {
      toast.error("Missing booking ID");
      navigate('/packages');
    }
  }, [bookingId, packageInfo, selectedDate, isMembership, navigate]);

  const handlePayment = async () => {
    setLoading(true);
    try {
      if (!packageInfo.priceId) {
        throw new Error("Price ID not found for this package");
      }

      // For memberships, use a placeholder or 'membership' as booking_id
      const checkoutBookingId = isMembership ? 'membership_checkout' : bookingId;

      // Call edge function to create Stripe checkout session
      const { data, error } = await supabase.functions.invoke('create-checkout-session', {
        body: {
          booking_id: checkoutBookingId,
          price_id: packageInfo.priceId,
          success_url: `${window.location.origin}/confirmation?${isMembership ? 'membership=true' : `booking_id=${bookingId}`}`,
          cancel_url: `${window.location.origin}/payment`,
          is_membership: isMembership
        }
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error("No checkout URL received");
      }
    } catch (error: any) {
      console.error('Payment error:', error);
      toast.error(error.message || "Failed to process payment");
      setLoading(false);
    }
  };

  if (!packageInfo) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">
            Complete Your Booking
          </h1>
          <p className="text-muted-foreground">
            You're one step away from your exclusive session with Caroline
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-foreground">Payment Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between text-foreground">
              <span>Package:</span>
              <span className="font-semibold">{packageInfo.type} - {packageInfo.duration}</span>
            </div>
            <div className="flex justify-between text-foreground">
              <span>Date:</span>
              <span className="font-semibold">
                {new Date(selectedDate).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
            </div>
            <div className="flex justify-between text-foreground">
              <span>Time:</span>
              <span className="font-semibold">
                {new Date(selectedDate).toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit'
                })} EST
              </span>
            </div>
            <div className="border-t pt-4 flex justify-between text-lg font-bold text-foreground">
              <span>Total:</span>
              <span>{packageInfo.price}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-muted/30 mb-6">
          <CardContent className="pt-6">
            <ul className="space-y-2 text-sm text-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Secure payment processing via Stripe</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Instant confirmation via email and WhatsApp</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Private video/audio call link will be sent 24 hours before</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Non-refundable once booked</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <div className="flex gap-4">
          <Button
            variant="outline"
            onClick={() => navigate('/calendar', { 
              state: { 
                bookingId, 
                packageInfo,
                isMembership 
              } 
            })}
            disabled={loading}
            className="flex-1"
          >
            Back
          </Button>
          <Button
            onClick={handlePayment}
            disabled={loading}
            className="flex-1"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              "Proceed to Payment"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { WhyBook } from "@/components/WhyBook";
import { HowItWorks } from "@/components/HowItWorks";
import { Link } from "react-router-dom";

const Index = () => {
  console.log("Caroline Stanbury page loaded");
  
  return (
    <main className="w-full">
      <Hero />
      <About />
      <WhyBook />
      <HowItWorks />
      
      {/* Admin Access Link */}
      <div className="w-full py-4 bg-background border-t">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <Link 
            to="/auth" 
            className="text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            Admin Access
          </Link>
        </div>
      </div>
    </main>
  );
};

export default Index;

import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Confirmation() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const bookingId = searchParams.get('booking_id');
  const [booking, setBooking] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!bookingId) {
      toast.error("No booking ID provided");
      navigate('/');
      return;
    }

    fetchBookingDetails();
  }, [bookingId, navigate]);

  const fetchBookingDetails = async () => {
    try {
      // Use secure edge function instead of direct database query
      const { data, error } = await supabase.functions.invoke('get-booking-details', {
        body: { booking_id: bookingId }
      });

      if (error) throw error;
      
      if (data?.booking) {
        setBooking(data.booking);
      }
    } catch (error: any) {
      console.error('Error fetching booking:', error);
      toast.error("Failed to load booking details");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-foreground">Booking Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/')} className="w-full">
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">
            Booking Confirmed! 🎉
          </h1>
          <p className="text-muted-foreground">
            Your exclusive session with Caroline Stanbury is confirmed
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-foreground">Session Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-foreground">
              <strong>Client Name:</strong> {booking.client_name}
            </div>
            <div className="text-foreground">
              <strong>Email:</strong> {booking.client_email}
            </div>
            <div className="text-foreground">
              <strong>Phone:</strong> {booking.client_phone}
            </div>
            <div className="text-foreground">
              <strong>Session Type:</strong> {booking.session_type.charAt(0).toUpperCase() + booking.session_type.slice(1)} Call
            </div>
            <div className="text-foreground">
              <strong>Duration:</strong> {booking.duration} minutes
            </div>
            <div className="text-foreground">
              <strong>Date & Time:</strong>{' '}
              {booking.selected_date
                ? new Date(booking.selected_date).toLocaleString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  }) + ' EST'
                : 'Not scheduled'}
            </div>
            <div className="text-foreground">
              <strong>Amount Paid:</strong> ${booking.price}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-primary/5 border-primary/20 mb-6">
          <CardHeader>
            <CardTitle className="text-foreground">What's Next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-foreground flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <span>You'll receive a confirmation email and WhatsApp message shortly</span>
            </p>
            <p className="text-foreground flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <span>A private video/audio call link will be sent 24 hours before your session</span>
            </p>
            <p className="text-foreground flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <span>Prepare any questions or topics you'd like to discuss with Caroline</span>
            </p>
            <p className="text-foreground flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <span>For any questions, contact us at support@stanburytalks.com</span>
            </p>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button onClick={() => navigate('/')} size="lg">
            Return to Home
          </Button>
        </div>
      </div>
    </div>
  );
}

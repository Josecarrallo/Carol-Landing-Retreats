import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, Sparkles } from "lucide-react";

export default function Registration() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    client_name: "",
    client_email: "",
    client_phone: "",
    call_topics: "",
    motivation: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Create booking via secure edge function (bypasses RLS)
      const { data, error } = await supabase.functions.invoke('create-booking', {
        body: {
          ...formData,
          session_type: "audio", // Default, will be selected in packages
          duration: 10,
          price: 275,
          status: "pending"
        }
      });

      if (error) throw error;
      
      const bookingData = data.booking;

      // Send confirmation via edge function
      const { error: emailError } = await supabase.functions.invoke('send-booking-confirmation', {
        body: {
          booking_id: bookingData.id,
          client_name: formData.client_name,
          client_email: formData.client_email,
          client_phone: formData.client_phone
        }
      });

      if (emailError) {
        console.error('Error sending confirmation:', emailError);
        // Don't block user flow if confirmation fails
      }

      toast.success("¡Registro exitoso! Bienvenido a la comunidad.");
      
      // Navigate to packages page to select a session
      navigate('/packages', { state: { bookingId: bookingData.id } });
    } catch (error: any) {
      console.error('Registration error:', error);
      toast.error(error.message || "Failed to register. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <Card>
          <CardHeader className="text-center">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="text-3xl">Begin Your Journey with Caroline</CardTitle>
            <CardDescription className="text-lg mt-2">
              Fill in your details to secure your exclusive 1:1 session
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="client_name">Full Name *</Label>
                <Input
                  id="client_name"
                  value={formData.client_name}
                  onChange={(e) => setFormData({ ...formData, client_name: e.target.value })}
                  required
                  placeholder="Your full name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="client_email">Email Address *</Label>
                <Input
                  id="client_email"
                  type="email"
                  value={formData.client_email}
                  onChange={(e) => setFormData({ ...formData, client_email: e.target.value })}
                  required
                  placeholder="your.email@example.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="client_phone">Phone Number (WhatsApp) *</Label>
                <Input
                  id="client_phone"
                  type="tel"
                  value={formData.client_phone}
                  onChange={(e) => setFormData({ ...formData, client_phone: e.target.value })}
                  required
                  placeholder="+1 234 567 8900"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="call_topics">What would you like to discuss with Caroline?</Label>
                <Textarea
                  id="call_topics"
                  value={formData.call_topics}
                  onChange={(e) => setFormData({ ...formData, call_topics: e.target.value })}
                  placeholder="Life challenges, relationships, personal growth, career..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="motivation">What's motivating you to book this session?</Label>
                <Textarea
                  id="motivation"
                  value={formData.motivation}
                  onChange={(e) => setFormData({ ...formData, motivation: e.target.value })}
                  placeholder="What's holding you back right now? What breakthrough are you seeking?"
                  rows={4}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                disabled={loading}
              >
                {loading ? "Registering..." : "Continue to Package Selection"}
              </Button>

              <p className="text-sm text-center text-muted-foreground">
                By registering, you'll receive a confirmation via email and WhatsApp
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

import { useNavigate, useLocation } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import carolineImage from "@/assets/caroline-vip-coaching.jpg";

export default function VIPCoaching() {
  const navigate = useNavigate();
  const location = useLocation();
  const bookingId = location.state?.bookingId;

  const handleContinue = () => {
    navigate('/vip-inner-circle', { state: { bookingId } });
  };

  return (
    <div className="h-screen bg-[hsl(var(--cream))] py-4 px-4 md:px-6 lg:px-12 overflow-hidden flex items-center">
      <div className="max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="mb-3">
          <h1 className="font-serif italic text-2xl md:text-3xl text-primary mb-0.5">
            Vip Coaching
          </h1>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-primary leading-tight">
            WELCOME TO<br />THE COMMUNITY!
          </h2>
        </div>

        {/* Main Content Grid */}
        <div className="grid md:grid-cols-2 gap-6 items-start">
          {/* Left Column */}
          <div className="space-y-3 overflow-y-auto max-h-[calc(100vh-12rem)] pr-2">
            {/* Description */}
            <div>
              <p className="text-foreground/80 leading-relaxed text-xs">
                Step into a powerful coaching experience designed to help you elevate your mindset, confidence, and lifestyle — directly with Caroline. This program is perfect for those who want personal guidance, accountability, and transformation — without the full commitment of Caroline's higher-tier mentorships.
              </p>
            </div>

            {/* What's Included */}
            <div className="space-y-2">
              <h3 className="font-semibold text-foreground text-sm">What's Included:</h3>
              
              <div className="space-y-2">
                <div>
                  <p className="text-foreground font-medium text-xs">
                    ✨ 2 × 30-Minute Private Zoom Sessions with Caroline
                  </p>
                  <p className="text-foreground/70 text-[10px] mt-0.5">
                    Focused, high-impact conversations to help you gain clarity, direction, and results in your personal or professional life. (Value: $1,000)
                  </p>
                </div>

                <div>
                  <p className="text-foreground font-medium text-xs">
                    ✨ 1 × 15-Minute Bonus Check-In
                  </p>
                  <p className="text-foreground/70 text-[10px] mt-0.5">
                    A quick yet powerful follow-up session to keep you aligned and motivated. (Value: $250)
                  </p>
                </div>

                <div>
                  <p className="text-foreground font-medium text-xs">
                    ✨ Priority Booking for Additional Calls
                  </p>
                  <p className="text-foreground/70 text-[10px] mt-0.5">
                    Need more time? As a VIP member, you get first priority to book extra private sessions with Caroline.
                  </p>
                </div>

                <div>
                  <p className="text-foreground font-medium text-xs">
                    ✨ Access to Exclusive Monthly Group Coaching Sessions
                  </p>
                  <p className="text-foreground/70 text-[10px] mt-0.5">
                    Join Caroline and other VIP clients in intimate group sessions where she shares strategies, mindset tools, and personal insights to accelerate your growth.
                  </p>
                </div>

                <div>
                  <p className="text-foreground font-medium text-xs">
                    ✨ Early Access to Retreats & Private Events
                  </p>
                  <p className="text-foreground/70 text-[10px] mt-0.5">
                    Be the first to know — and the first invited — when new retreats, experiences, or collaborations launch.
                  </p>
                </div>
              </div>
            </div>

            {/* Additional Info */}
            <div className="space-y-2">
              <p className="text-foreground/80 leading-relaxed text-xs">
                VIP Coaching gives you direct access to Caroline's mentorship, mindset, and proven strategies in a flexible and accessible format — ideal for those ready to step into their next level of confidence, business, and personal transformation.
              </p>

              <div>
                <p className="text-foreground/80 mb-1 text-xs">Much love,</p>
                <p className="font-serif italic text-2xl text-primary">
                  Caroline Stanbury
                </p>
              </div>
            </div>

            {/* Continue Button */}
            <div className="mt-3">
              <Button
                onClick={handleContinue}
                size="lg"
                className="px-6 py-4 text-sm w-full md:w-auto"
              >
                Continue
              </Button>
            </div>
          </div>

          {/* Right Column */}
          <div className="flex items-start justify-center">
            {/* Caroline's Image with JOIN US Badge */}
            <div className="relative max-w-md">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <img 
                  src={carolineImage}
                  alt="Caroline Stanbury"
                  className="w-full h-auto object-cover max-h-[calc(100vh-10rem)]"
                />
              </div>
              
              {/* JOIN US Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full bg-[hsl(var(--accent-pink))] flex items-center justify-center shadow-xl rotate-12 border-4 border-white">
                    <div className="text-center -rotate-12">
                      <div className="text-white font-bold text-base leading-tight">
                        JOIN<br />US
                      </div>
                      <div className="flex justify-center gap-0.5 mt-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Sparkles key={i} className="w-1.5 h-1.5 text-white fill-white" />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

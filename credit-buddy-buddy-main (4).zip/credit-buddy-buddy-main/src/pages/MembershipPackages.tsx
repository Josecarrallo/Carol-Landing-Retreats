import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, CheckCircle2, Crown, Gem, Star } from "lucide-react";

const membershipPackages = [
  {
    name: "VIP Coaching",
    price: 950,
    icon: Star,
    features: [
      "2 × 30-minute Zoom video calls with Caroline (value $1,000)",
      "1 × 15-minute bonus call (value $250)",
      "Priority booking for extra calls",
      "Access to exclusive group coaching sessions (monthly)",
      "Early access to retreats & private events"
    ]
  },
  {
    name: "VVIP Inner Circle",
    price: 3000,
    icon: Crown,
    popular: true,
    features: [
      "4 × 30-minute Zoom video calls with Caroline (value $2,000)",
      "2 × 15-minute bonus calls (value $500)",
      "Invitation to monthly mastermind session with Caroline (small group, high level)",
      "VIP treatment at all Caroline events",
      "Exclusive access to limited opportunities (first priority on new retreats/collaborations)"
    ]
  },
  {
    name: "Elite Founders Circle",
    price: 7000,
    icon: Gem,
    premium: true,
    features: [
      "Everything in VVIP",
      "Free access to one luxury retreat per year (worth $8,000–$12,000)",
      "Private 1:1 dinner or in-person session at the retreat",
      "Limited to 5 members worldwide — Caroline's closest circle"
    ]
  }
];

export default function MembershipPackages() {
  const navigate = useNavigate();

  const handleSelectMembership = (membership: typeof membershipPackages[0]) => {
    // Navigate directly to calendar with membership info
    navigate('/calendar', {
      state: {
        packageInfo: {
          type: membership.name,
          price: `$${membership.price}`,
          priceId: `price_membership_${membership.name.toLowerCase().replace(/\s+/g, '_')}`,
          isMembership: true
        }
      }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 py-6 px-4">
      <div className="max-w-7xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-6 bg-gradient-to-r from-primary via-orange-500 to-primary bg-clip-text text-transparent animate-fade-in">
            Coaching Memberships
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose your commitment level
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {membershipPackages.map((membership, index) => {
            const Icon = membership.icon;
            return (
              <Card 
                key={index} 
                className={`relative hover:shadow-lg transition-shadow flex flex-col ${
                  membership.premium ? 'border-primary border-2' : ''
                }`}
              >
                {membership.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                    MOST POPULAR
                  </Badge>
                )}
                {membership.premium && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary via-orange-500 to-yellow-500 text-white">
                    EXCLUSIVE
                  </Badge>
                )}
                <CardHeader className="flex-none p-4">
                  <Icon className="w-8 h-8 mb-2 text-primary" />
                  <CardTitle className="text-xl">{membership.name}</CardTitle>
                  <div className="text-3xl font-bold text-primary mt-2">
                    ${membership.price.toLocaleString()}
                    <span className="text-sm font-normal text-primary">/mo</span>
                  </div>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col p-4 pt-0">
                  <ul className="space-y-1.5 flex-grow">
                    {membership.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-xs">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="mt-auto p-4 pt-0">
                  <Button 
                    className="w-full"
                    onClick={() => handleSelectMembership(membership)}
                  >
                    Select Membership
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>

        <Card className="mt-6 bg-muted/30">
          <CardHeader className="p-4">
            <CardTitle className="text-lg">Membership Benefits</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0 grid md:grid-cols-2 gap-2">
            <p className="flex items-start gap-2 text-sm">
              <span className="text-primary font-bold">•</span>
              <span>Ongoing expertise access</span>
            </p>
            <p className="flex items-start gap-2 text-sm">
              <span className="text-primary font-bold">•</span>
              <span>Continuous support</span>
            </p>
            <p className="flex items-start gap-2 text-sm">
              <span className="text-primary font-bold">•</span>
              <span>Priority event access</span>
            </p>
            <p className="flex items-start gap-2 text-sm">
              <span className="text-primary font-bold">•</span>
              <span>High achiever community</span>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

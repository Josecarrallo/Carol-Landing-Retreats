import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Loader2, LogOut, RefreshCw, MessageSquare, Video, Download } from 'lucide-react';

interface Booking {
  id: string;
  client_name: string;
  client_email: string;
  client_phone: string;
  session_type: string;
  duration: number;
  price: number;
  selected_date: string;
  status: string;
  call_topics: string;
  motivation: string;
  video_call_link: string;
  payment_id: string;
  stripe_payment_intent_id: string;
  created_at: string;
  updated_at: string;
}

export default function Admin() {
  const { user, isAdmin, loading: authLoading, signOut } = useAuth();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [groupCallLink, setGroupCallLink] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    } else if (!authLoading && user && !isAdmin) {
      toast.error('No tienes permisos de administrador');
      navigate('/');
    }
  }, [user, isAdmin, authLoading, navigate]);

  const fetchBookings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBookings(data || []);
    } catch (error: any) {
      toast.error('Error al cargar las reservas');
      console.error('Error fetching bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && isAdmin) {
      fetchBookings();
    }
  }, [user, isAdmin]);

  const handleSendMassMessage = async () => {
    if (!message.trim()) {
      toast.error('Por favor escribe un mensaje');
      return;
    }

    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke('send-mass-whatsapp', {
        body: {
          message: message.trim(),
          groupCallLink: groupCallLink.trim() || undefined
        }
      });

      if (error) throw error;

      toast.success(data.message || 'Mensajes enviados exitosamente');
      setMessage('');
      setGroupCallLink('');
    } catch (error: any) {
      console.error('Error sending mass message:', error);
      toast.error(error.message || 'Error al enviar mensajes');
    } finally {
      setSending(false);
    }
  };

  const exportToCSV = () => {
    if (bookings.length === 0) {
      toast.error('No hay datos para exportar');
      return;
    }

    const headers = [
      'ID',
      'Cliente',
      'Email',
      'Teléfono',
      'Tipo de Sesión',
      'Duración (min)',
      'Precio',
      'Fecha Seleccionada',
      'Estado',
      'Temas de Llamada',
      'Motivación',
      'Link Video Llamada',
      'ID de Pago',
      'Stripe Payment Intent',
      'Fecha de Creación',
      'Última Actualización'
    ];

    const csvContent = [
      headers.join(','),
      ...bookings.map(booking => [
        booking.id,
        `"${booking.client_name}"`,
        booking.client_email,
        booking.client_phone,
        `"${booking.session_type}"`,
        booking.duration,
        booking.price,
        booking.selected_date ? new Date(booking.selected_date).toLocaleString('es-ES') : 'Pendiente',
        booking.status,
        `"${booking.call_topics || ''}"`,
        `"${booking.motivation || ''}"`,
        booking.video_call_link || '',
        booking.payment_id || '',
        booking.stripe_payment_intent_id || '',
        new Date(booking.created_at).toLocaleString('es-ES'),
        new Date(booking.updated_at).toLocaleString('es-ES')
      ].join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `reservas_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Datos exportados correctamente');
  };

  if (authLoading || !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Panel de Administración</h1>
            <p className="text-muted-foreground">Gestión de Reservas - Caroline</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={exportToCSV} disabled={loading || bookings.length === 0}>
              <Download className="h-4 w-4 mr-2" />
              Exportar CSV
            </Button>
            <Button variant="outline" onClick={fetchBookings} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Actualizar
            </Button>
            <Button variant="outline" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Mensaje Masivo por WhatsApp
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Mensaje para todas las clientas</label>
                <Textarea
                  placeholder="Escribe tu mensaje aquí..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
              </div>
              <Button 
                onClick={handleSendMassMessage} 
                disabled={sending || !message.trim()}
                className="w-full"
              >
                {sending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Enviar a Todas ({bookings.length})
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="h-5 w-5" />
                Llamada Grupal
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Link de Google Meet / Zoom</label>
                <Input
                  placeholder="https://meet.google.com/xxx-xxxx-xxx"
                  value={groupCallLink}
                  onChange={(e) => setGroupCallLink(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Mensaje de invitación</label>
                <Textarea
                  placeholder="Ej: ¡Te invito a nuestra sesión grupal especial! Únete para compartir experiencias..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
              </div>
              <Button 
                onClick={handleSendMassMessage}
                disabled={sending || !message.trim() || !groupCallLink.trim()}
                className="w-full"
              >
                {sending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Enviando invitaciones...
                  </>
                ) : (
                  <>
                    <Video className="h-4 w-4 mr-2" />
                    Enviar Link a Todas ({bookings.length})
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Reservas ({bookings.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : bookings.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">No hay reservas todavía</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Duración</TableHead>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Precio</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Temas</TableHead>
                      <TableHead>Motivación</TableHead>
                      <TableHead>ID Pago</TableHead>
                      <TableHead>Creada</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.client_name}</TableCell>
                        <TableCell>{booking.client_email}</TableCell>
                        <TableCell>{booking.client_phone}</TableCell>
                        <TableCell>{booking.session_type}</TableCell>
                        <TableCell>{booking.duration} min</TableCell>
                        <TableCell>
                          {booking.selected_date 
                            ? new Date(booking.selected_date).toLocaleDateString('es-ES', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })
                            : 'Pendiente'}
                        </TableCell>
                        <TableCell>${booking.price}</TableCell>
                        <TableCell>
                          <Badge variant={booking.status === 'paid' ? 'default' : 'secondary'}>
                            {booking.status === 'paid' ? 'Pagado' : 'Pendiente'}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {booking.call_topics || '-'}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {booking.motivation || '-'}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {booking.payment_id || '-'}
                        </TableCell>
                        <TableCell>
                          {new Date(booking.created_at).toLocaleDateString('es-ES', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric'
                          })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

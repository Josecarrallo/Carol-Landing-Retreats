import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import Registration from "./pages/Registration";
import Packages from "./pages/Packages";
import Calendar from "./pages/Calendar";
import Payment from "./pages/Payment";
import Confirmation from "./pages/Confirmation";
import Auth from "./pages/Auth";
import Admin from "./pages/Admin";
import CoachingMemberships from "./pages/CoachingMemberships";
import MembershipPackages from "./pages/MembershipPackages";
import VIPCoaching from "./pages/VIPCoaching";
import VIPInnerCircle from "./pages/VIPInnerCircle";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/registration" element={<Registration />} />
            <Route path="/packages" element={<Packages />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/confirmation" element={<Confirmation />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/coaching-memberships" element={<CoachingMemberships />} />
            <Route path="/membership-packages" element={<MembershipPackages />} />
            <Route path="/vip-coaching" element={<VIPCoaching />} />
            <Route path="/vip-inner-circle" element={<VIPInnerCircle />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
